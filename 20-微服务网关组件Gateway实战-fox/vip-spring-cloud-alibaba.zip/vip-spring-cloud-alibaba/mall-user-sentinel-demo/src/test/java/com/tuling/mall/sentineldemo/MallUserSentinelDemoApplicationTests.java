package com.tuling.mall.sentineldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallUserSentinelDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
