package com.tuling.mall.gatewaysentineldemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallGatewaySentinelDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
