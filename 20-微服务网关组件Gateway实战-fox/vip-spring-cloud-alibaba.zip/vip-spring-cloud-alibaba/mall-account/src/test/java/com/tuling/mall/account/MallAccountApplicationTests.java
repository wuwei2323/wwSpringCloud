package com.tuling.mall.account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
