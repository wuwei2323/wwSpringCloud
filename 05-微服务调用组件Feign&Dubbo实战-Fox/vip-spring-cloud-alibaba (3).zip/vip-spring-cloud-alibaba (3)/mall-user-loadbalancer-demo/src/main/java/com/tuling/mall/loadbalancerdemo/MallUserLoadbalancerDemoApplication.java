package com.tuling.mall.loadbalancerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallUserLoadbalancerDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MallUserLoadbalancerDemoApplication.class, args);
    }

}
